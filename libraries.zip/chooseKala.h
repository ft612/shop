#ifndef CHOOSEALA_H
#define CHOOSEALA_H
#include"kala.h"

class chooseKala
{
public:
    chooseKala();

public:

};

#endif // CHOOSEALA_H
