#include "chooseKala.h"

chooseKala::chooseKala()
{

}
